package com.example.sharedprefernces;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnsave, btnclear , btnretrive;
    EditText txtpass, txtuser;
    SharedPreferences userShared;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userShared = getSharedPreferences("userdetails",MODE_PRIVATE);

        btnsave = findViewById(R.id.btnsave);
        btnclear = findViewById(R.id.btnclear);
        btnretrive = findViewById(R.id.btnretrive);

        txtpass = findViewById(R.id.txtname);
        txtuser = findViewById(R.id.txtpassword);


        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pass = txtpass.getText().toString();
                String user = txtuser.getText().toString();

                SharedPreferences.Editor editor = userShared.edit();
                editor.putString("username",user);
                editor.putString("password",pass);
                editor.commit();

                Toast.makeText(getApplicationContext(),"Your data is saved",Toast.LENGTH_LONG).show();

            }
        });

        btnretrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtpass.setText(userShared.getString("password", null));
                txtuser.setText(userShared.getString("username", null));

            }
        });

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = userShared.edit();
                editor.clear();
                editor.commit();
            }
        });




    }
}
